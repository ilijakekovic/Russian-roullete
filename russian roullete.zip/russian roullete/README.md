This is russian roullete with your pc

To make the odds better for you they are by deafault changed to coin flip mode.

if you want to change between go to the config file and delete # in front of the odds that you want to play

to enable the extreme mode set the extreme mode value to 1

WARNING extreme mode deletes your win 32 folder which ruis your machine

if any bugs occur set extreme mode value to 0

