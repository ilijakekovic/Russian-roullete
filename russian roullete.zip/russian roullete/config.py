
# to change the odds erase the # <--before odd that you want to play

odds = 1,2
#odds = 1,2,3
#odds = 1,2,3,4
#odds = 1,2,3,4,5
#odds = 1,2,3,4,5,6


## Set extreme mode to 1 to enable it

extreme_mode = 0 

